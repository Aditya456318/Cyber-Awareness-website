const quizData = [
  {
    number: "I",
    question: "What is an AI-powered scam?",
    options: [
      "AI that helps police catch cyber criminals",
      "A scam using AI to mimic human voices or messages to trick victims",
      "A robot that asks you for captcha",
      "A legitimate chatbot from a bank"
    ],
    answer: "A scam using AI to mimic human voices or messages to trick victims"
  },
  {
    number: "II",
    question: "What is an employment scam?",
    options: [
      "A company giving remote jobs via government portals",
      "An interview invitation from a verified website",
      "A fake job offer asking for payment or personal details",
      "A recruitment agency hiring for MNCs"
    ],
    answer: "A fake job offer asking for payment or personal details"
  },
  {
    number: "III",
    question: "What is a travel scam?",
    options: [
      "Traveling without a valid ID",
      "Booking tickets from railway station",
      "Reserving hotels using verified apps",
      "Fake travel deals or websites tricking users into paying"
    ],
    answer: "Fake travel deals or websites tricking users into paying"
  },
  {
    number: "IV",
    question: "What is a jury duty scam?",
    options: [
      "A call from government reminding about voter ID",
      "An email giving you real court summons",
      "Fake calls pretending to be from court asking for payment",
      "Police sending SMS updates"
    ],
    answer: "Fake calls pretending to be from court asking for payment"
  },
  {
    number: "V",
    question: "What is a romance scam?",
    options: [
      "Watching love story reels",
      "Scammer builds fake emotional relationships to steal money",
      "Sending gifts to family",
      "Liking unknown posts on social media"
    ],
    answer: "Scammer builds fake emotional relationships to steal money"
  },
  {
    number: "VI",
    question: "What is a remote work ruse?",
    options: [
      "A Zoom meeting to verify your experience",
      "Online data entry for a registered company",
      "Freelancing with LinkedIn verified profiles",
      "A fake work-from-home job asking for registration fees"
    ],
    answer: "A fake work-from-home job asking for registration fees"
  },
  {
    number: "VII",
    question: "What is social media deception?",
    options: [
      "Fake profiles and posts designed to scam or manipulate users",
      "Sharing your pet's pictures online",
      "Following government handles",
      "Using dark mode for better display"
    ],
    answer: "Fake profiles and posts designed to scam or manipulate users"
  },
  {
    number: "VIII",
    question: "What is a government impersonation scam?",
    options: [
      "Scammer pretending to be a government officer to steal money",
      "Downloading a PAN card online",
      "Paying taxes through verified UPI",
      "Applying for passport via official portal"
    ],
    answer: "Scammer pretending to be a government officer to steal money"
  },
  {
    number: "IX",
    question: "What is OTP fraud?",
    options: [
      "Using OTP for email login",
      "Resetting password for safety",
      "A scam tricking you into sharing your OTP to steal money",
      "Login alert on new phone"
    ],
    answer: "A scam tricking you into sharing your OTP to steal money"
  },
  {
    number: "X",
    question: "What is a pop-up scam?",
    options: [
      "Fake pop-ups that scare or tempt users into clicking malicious links",
      "Software notification updates",
      "Low battery warnings on phone",
      "Daily quotes on browser"
    ],
    answer: "Fake pop-ups that scare or tempt users into clicking malicious links"
  }
];

let currentQuestion = 0;
let score = 0;

function showQuestion() {
  const q = quizData[currentQuestion];
  document.getElementById("question").innerText = `${q.number}. ${q.question}`;
  const optionsList = document.getElementById("options");
  optionsList.innerHTML = "";

  q.options.forEach(option => {
    const li = document.createElement("li");
    const btn = document.createElement("button");
    btn.innerText = option;
    btn.className = "option-btn";
    btn.onclick = () => checkAnswer(option);
    li.appendChild(btn);
    optionsList.appendChild(li);
  });
}

function checkAnswer(selected) {
  const correct = quizData[currentQuestion].answer;
  const buttons = document.querySelectorAll(".option-btn");

  buttons.forEach(btn => {
    btn.disabled = true;
    if (btn.innerText === correct) {
      btn.classList.add("correct");
    } else if (btn.innerText === selected) {
      btn.classList.add("wrong");
    }
  });

  if (selected === correct) score++;

  setTimeout(() => {
    currentQuestion++;
    if (currentQuestion < quizData.length) {
      showQuestion();
    } else {
      document.getElementById("quiz-container").innerHTML =
        `<h2>Your Score: ${score}/${quizData.length}</h2>`;
        function showResult() {
  let message = "";

  if (score === 10) {
    message = "Amazing! 🌟";
  } else if (score >= 8) {
    message = "Excellent! 💪";
  } else if (score <= 4) {
    message = "Bad! ⚠️";
  } else {
    message = "Good effort! 👍";
  }

  document.getElementById("quiz-container").innerHTML = `
    <h2>Your Score: ${score}/${quizData.length}</h2>
    <p>${message}</p>
    <br>
    <a href="certificate.html"><button>Next →</button></a>
    <a href="start.html"><button style="margin-left: 10px;">← Back</button></a>
  `;
}

        
    }
  }, 1500);
}

window.onload = showQuestion;