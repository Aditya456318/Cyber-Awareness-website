function switchLanguage() {
  const elements = document.querySelectorAll('[data-en]');
  elements.forEach(el => {
    const currentLang = document.documentElement.lang;
    if (currentLang === 'en') {
      el.innerText = el.getAttribute('data-hi');
      document.documentElement.lang = 'hi';
    } else {
      el.innerText = el.getAttribute('data-en');
      document.documentElement.lang = 'en';
    }
  });
}